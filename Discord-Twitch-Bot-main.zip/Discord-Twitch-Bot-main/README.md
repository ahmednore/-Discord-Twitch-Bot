# Discord Twitch follow bot
This is a free twitch bot for discord


# ・How to use
・Place token in config

・Change prefix to whatever you want in config

# ・About

・Leave all Suggestions in a pull request or issue

・It takes 2 seconds to star, longer to maintain :)

## ・Features
```
・Twitch follow

```

 ## 🥅 ・Goals

・ 10 Stars It's decent :D

・ 20  stars omg maybe some people actually seen it now

## Support me
・Join my discord
https://discord.gg/phts


## ・Skids
Uh idc lol


## 📄・License

This project is licensed under the GPL General Public License v3.0 License - see the [LICENSE.md](./LICENSE) file for details
```js
  ・Educational purpose only and all your consequences caused by you actions is your responsibility
  ・Selling this Free gen is forbidden
  ・If you make a copy of this/or fork it, it must be open-source and have credits linking to this repo
```


## 💭・ChangeLog

```diff
v1 ⋮ 08/7/22
+ Stable Release
+ Config
+ Role Config
+ Channel Lock
```



## 💭・To do

・Add logs

・Add More commands

・Help embed

・Tell me more idea's



This is demonstrating that twitch have no security, educational use only!
